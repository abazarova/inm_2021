#include"matrix.h"

void simple_iteration();
