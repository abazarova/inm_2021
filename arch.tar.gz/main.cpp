#include<iostream>
#include"simple_iteration.h"

int main(){
	simple_iteration();
	return 0;
}
